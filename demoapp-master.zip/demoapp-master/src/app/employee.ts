export class Employee {

    private id:number;
    private employeeName:String;
    private department:String;
    private date:Date;
}
