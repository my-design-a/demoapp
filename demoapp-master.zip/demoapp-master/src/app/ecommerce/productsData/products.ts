export class Products {

     productId:number;
     productName:string;
     productDescription:string;
     productOriginalPrice:number;
     productDiscountPrice:number;
     productImageUrl:string;
     quantity:number;
}
