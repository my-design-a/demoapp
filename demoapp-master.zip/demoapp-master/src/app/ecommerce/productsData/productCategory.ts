export class ProductCategory{
    
        productCategoryId : number;
        productCategoryImageUrl : string;
        productCategoryName : string;
        productCategoryTeluguName : string;
}