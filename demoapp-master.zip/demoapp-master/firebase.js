var firebaseConfig = {
    apiKey: "AIzaSyB5BEu91byJ060u5pJUk7r9O0ZReRX2Vhs",
    authDomain: "vnrsf-40e18.firebaseapp.com",
    databaseURL: "https://vnrsf-40e18.firebaseio.com",
    projectId: "vnrsf-40e18",
    storageBucket: "vnrsf-40e18.appspot.com",
    messagingSenderId: "958479216820",
    appId: "1:958479216820:web:f8b889e33146af948de7e1",
    measurementId: "G-0WY698GDY1"
  };